/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee.Patient;

/**
 *
 * @author Aayush
 */
public class FamilyHistory {
    private String medicalProblem;
    private String relationship;

    public FamilyHistory(String medicalProblem, String relationship) {
        this.medicalProblem = medicalProblem;
        this.relationship = relationship;
    }
    
    
          
}
