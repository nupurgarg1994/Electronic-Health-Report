/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee.Patient;

import java.util.Date;

/**
 *
 * @author Aayush
 */
public class VitalSigns {
    private float weight;
    private float bodyTemp;
    private float bloodPressure;
    private float pulse;
    private String initials;
    private Date lastUpdated;
    private String updatedBy;
    
    
}
