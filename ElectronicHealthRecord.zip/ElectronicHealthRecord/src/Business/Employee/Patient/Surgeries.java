/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee.Patient;

import java.util.Date;

/**
 *
 * @author Aayush
 */
public class Surgeries {
    private Date date;
    private String preOperativeDiagnosis;
    private String  postOperativeDiagnosis;
    private String procedure;
    private String surgeon;
    private String assistant;
    private String anesthesia;
    private String anesthesioLogist;
           
    
}
