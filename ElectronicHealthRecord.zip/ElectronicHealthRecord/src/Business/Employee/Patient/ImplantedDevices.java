/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee.Patient;

import java.util.Date;

/**
 *
 * @author Aayush
 */
public class ImplantedDevices {
    private String mfgGroup;
    private String product;
    private String modelNo;
    private String serialNo;
    private Date implantDate;
    private String doctorName;
    private String doctorDesg;
    
    
}
