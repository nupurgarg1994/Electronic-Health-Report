/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee.Patient;

import java.util.Date;

/**
 *
 * @author Aayush
 */
public class MedicalHistory {
    private String condition;
    private String status;
    private String prescriptionId;
    private String observedBy;
    private Date observedDate;
    private Date resolvedDate;
    
    
}
