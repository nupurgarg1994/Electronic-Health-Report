/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee.Patient;

import java.util.Date;

/**
 *
 * @author Aayush
 */
public class Immunizations {
    private String vaccine;
    private Date vaccinationDate;
    private String doctorName;
    private String doctorDesg;
    private String vaccineManufacturer;
    private String batchNo;
    private String validPeriod;
    private String active;
           
    
    
}
